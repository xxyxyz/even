from _numpypy.umath import *

import math
e = math.e
pi = math.pi
del math

PZERO = 0.0
NZERO = -0.0
PINF = float('inf')
NINF = float('-inf')
NAN = float('nan')
